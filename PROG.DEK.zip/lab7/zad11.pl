% Rozpoznanie wielomian�w jednej zmiennej
% o wsp�czynnikach liczbowych

/*
Definicja:rekurencja struktura;na

1) X jest wielomianem zmiennej X
   C - liczba jest wielomianem dowolnej zmiennej

2) je�eli W, w1, w2 s� wielomianami zmiennej X to 
	-W, W1+W2, W1-W2, W1*W2, W^N  (N- liczba naturalna)
	s� wielomianami zmiennej X 
*/

% wielomian(W,X)
% spe�niony,gdy w jest wielomianem zmiennej X
% o wsp�lczynnikach liczbowych
% definicja rekurecyjna

% warunki zako�czenia rekurencji
          wielomian(X,X).
	  wielomian(C,_):-number(C).
		  
% rekurencja
        wielomian(-W,X):-wielomian(W,X).
	wielomian(W1+W2,X):-wielomian(W1,X),
		            wielomian(W2,X).
	wielomian(W1-W2,X):-wielomian(W1,X),
		            wielomian(W2,X).
	wielomian(W1*W2,X):-wielomian(W1,X),
		            wielomian(W2,X).
	wielomian(W^N,X):-integer(N),
			  N>1,							  		  wielomian(W,X).
wielomian(y,y).
wielomian(3,x).


   