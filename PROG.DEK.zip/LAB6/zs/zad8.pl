na(d,c).
na(c,a).
na(c,b).
na(a,e).
na(b,g).
nad(X,Y):-na(X,Y).
nad(X,Y):-na(X,Z),nad(Z,Y).


/*
czy klocek d le�y nad klockiem a?
?-nad(d,a).
false.

Czy klocek d le�y nad klockiem e?
?-nad(d,e).
false.

*** czemu nie dziala ????????
Nad jakim klockiem le�y klocek d?
?-nad(d,X).
X = c ;
X = a ;
X = b ;
X = e ;
X = g ;


Czy jaki� klocek le�y nad klockiem b?
?-nad(_,b).
true ; 
true ;
false.

Czy klocek g le�y nad jakim� klockiem?
?-nad(g,_).




*\