rodzic(ania, jacek).
rodzic(jan, jacek).

rodzic(ania, basia).
rodzic(jan, basia).

rodzic(stefan, jan).

rodzic(maria, ania).
rodzic(borys, ania).

rodzic(ania, zosia).
rodzic(marian, zosia).

przodek(X,Y):-rodzic(X,Y).
przodek(X,Y):-rodzic(X,Z),przodek(Z,Y).

/*
Ania i jan s� rodzicami Jakuba
ania i jan s� rodzicami Basii
Stefan jest rodzicem Jana
Maria i Borys s� rodzicami Anii
rodzic(X,Y):-spe�niony, gdy X jest rodzicem Y
przodek(X,Y):-spe�niony, gdy X jest przodkiem Y
*\